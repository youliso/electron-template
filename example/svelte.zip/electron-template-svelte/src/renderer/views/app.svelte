<script lang='ts'>
  import { windowShow } from '@/renderer/utils/window';
  import customize from '@/renderer/store/customize';
  import Head from '@/renderer/views/components/head/index.svelte';

  windowShow(customize.data.id);
</script>

<Head />
<div class='container padding'>
  {JSON.stringify(customize.data)}
</div>
