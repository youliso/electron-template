<div class='head-info drag'>
  <div class='content'>
    {#if isMacintosh}
      <div></div>
      <div class='title'>
        {title }
      </div>
    {:else}
      <div class='title'>
        { title }
      </div>
      {#if eventShow}
        <div class='events'>
          <div on:click='{min}' class='event min no-drag'></div>
          <div on:click='{maxMin}' class='event max-min no-drag'></div>
          <div on:click='{close}' class='event close no-drag'></div>
        </div>
      {/if}
    {/if}
  </div>
</div>

<script lang='ts'>
  import { getGlobal } from '@/renderer/utils';
  import { windowClose, windowMaxMin, windowMin } from '@/renderer/utils/window';
  import customize from '@/renderer/store/customize';

  const customizeData = customize.get();
  export let eventShow = true;
  let isMacintosh = getGlobal('system.platform') === 'darwin';
  let title = customizeData.title || getGlobal('app.name');

  function min() {
    windowMin(customizeData.id);
  }

  function maxMin() {
    windowMaxMin(customizeData.id);
  }

  function close() {
    windowClose(customizeData.id);
  }
</script>

<style lang='scss'>
  @import './scss/index.scss';
</style>
