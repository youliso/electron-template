import customize from '@/renderer/store/customize';
import { windowLoad } from '@/renderer/utils/window';
import { domPropertyLoad } from '@/renderer/utils/dom';
import App from '@/renderer/views/app.tsx';
import '@/renderer/views/scss/color.scss';
import '@/renderer/views/scss/index.scss';

windowLoad((_, args) => {
  customize.set(args);
  domPropertyLoad();
  App();
});
