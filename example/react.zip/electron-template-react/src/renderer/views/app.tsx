import React from 'react';
import ReactDOM from 'react-dom';
import customize from '@/renderer/store/customize';
import { windowShow } from '@/renderer/utils/window';
import './scss/color.scss';
import './scss/index.scss';

export default function () {
  const args = customize.get();
  ReactDOM.render(<div className={'container'}>Hello, world!</div>, document.getElementById('app'));
  windowShow(args.id);
}
