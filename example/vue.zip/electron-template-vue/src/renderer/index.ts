import { createApp } from 'vue';
import customize from '@/renderer/store/customize';
import { windowLoad } from '@/renderer/utils/window';
import { domPropertyLoad } from '@/renderer/utils/dom';
import App from '@/renderer/views/app.vue';
import router from '@/renderer/router';

windowLoad((_, args) => {
  router.addRoute({
    path: '/',
    redirect: args.route
  });
  customize.set(args);
  domPropertyLoad();
  createApp(App).use(router).mount('#app');
});
